﻿using System.Reflection;

[assembly: AssemblyTitle("Catch_Connect_Crestron_Library")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Catch_Connect_Crestron_Library")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

